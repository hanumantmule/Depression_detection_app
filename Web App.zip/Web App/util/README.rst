Control TAC
========================

This project is about the analysis of text to predict the level on anxiety.

`Learn more <http://dcapswoz.ict.usc.edu/wwwutil_files/DAICWOZDepression_Documentation.pdf`_.

---------------