WINDOWS_SIZE = 10   # length of words contained in the windows used for training
model_name = "multi-fusion_model.json"
weights_name = "fusion_weights.h5"
data_path = 'E:\\Studies\\sem II\\WSC\\project\\final-app\\depression-detection-webapp\\data\\'
